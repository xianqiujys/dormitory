package com.jojo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jojo.entity.Admin;
import com.jojo.entity.Building;
import com.jojo.entity.Dormitory;
import com.jojo.entity.Hunhe;
import com.jojo.entity.Hunhe2;
import com.jojo.entity.Hunhe3;
import com.jojo.entity.Repair;
import com.jojo.entity.Student;
import com.jojo.utils.JDBCUtils;


public class Dao_Dormitory {
	public Student getOneStudent(String username)  {                     //���һ��ѧ������Ϣ    
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "select * from student where stdPId=?";
		try
		{	
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setString(1, username);			
			rs  = stmt.executeQuery();
			if(rs.next()){
				Student stud = new Student();
				stud.setStdPId(rs.getString("stdPId"));
				stud.setStdBId(rs.getString("stdBId"));
				stud.setStdDId(rs.getInt("stdDId"));
				stud.setStdClass(rs.getString("stdClass"));
				stud.setStdEmail(rs.getString("stdEmail"));
				stud.setStdJob(rs.getString("stdJob"));
				stud.setStdName(rs.getString("stdName"));
				stud.setStdPassword(rs.getString("stdPassword"));
				stud.setStdSex(rs.getString("stdSex"));
				stud.setStdStatus(rs.getInt("stdStatus"));
				stud.setStdTel(rs.getString("stdTel"));
				return stud;
			}
			return null;	
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
			
		}
		finally
		{
			 		
		}
	}
    public Building getOneBuilding(String username)             //���һ��¥����Ϣ
    {
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "select * from student,building,dormitory where student.stdPId=? and student.stdBId=building.buildBId and student.stdDId=dormitory.dorId";
		try
		{	
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setString(1, username);			
			rs  = stmt.executeQuery();
			if(rs.next()){
				Building buil = new Building();
				buil.setBuildBId(rs.getString("buildBId"));
				buil.setBuildFloor(rs.getInt("buildFloor"));
				buil.setBuildName(rs.getString("buildName"));
				buil.setBuildStyle(rs.getString("buildStyle"));
				return buil;
			}
			return null;	
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
			
		}
		finally
		{
			
		}
    }
    public Dormitory getOneDormitory(String username)            //���һ���������Ϣ
    {
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "select * from student,building,dormitory where student.stdPId=? and student.stdBId=building.buildBId and student.stdDId=dormitory.dorId";
		try
		{	
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setString(1, username);			
			rs  = stmt.executeQuery();
			if(rs.next()){
				Dormitory dor = new Dormitory();
				dor.setDorId(rs.getInt("dorId"));
				dor.setDorDId(rs.getInt("dorDId"));
				dor.setDorBId(rs.getString("dorBId"));
				dor.setDorPnum(rs.getInt("dorPnum"));
				dor.setDorAnum(rs.getInt("dorAnum"));
				dor.setDorGrade(rs.getInt("dorGrade"));
				dor.setDorName(rs.getString("dorName"));
				return dor;
			}
			return null;	
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
			
		}
		finally
		{
			
		}
    }
    public List<Hunhe> gethunhe(int username,int start) {                      //��ȡ���û���hunhe��������ҳ
		PreparedStatement stmt=null;
		ResultSet rs =null;
		if(start != 0)start = start*4;
		String sql = "select * from student,building,dormitory,stay where student.stdPId=stay.stayPId and dormitory.dorId=? and student.stdBId=building.buildBId and student.stdDId=dormitory.dorId limit "+start+","+4;
		try
		{
			List<Hunhe> list= new ArrayList<Hunhe>();
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, username);		
			rs  = stmt.executeQuery();
			while(rs.next()){
				Hunhe hunhe = new Hunhe();
				hunhe.setStdPId(rs.getString("stdPId"));
				hunhe.setStdName(rs.getString("stdName"));
				hunhe.setStdTel(rs.getString("stdTel"));
				hunhe.setStdSex(rs.getString("stdSex"));
				hunhe.setStdClass(rs.getString("stdClass"));
				hunhe.setStdEmail(rs.getString("stdEmail"));
				hunhe.setStdDId(rs.getInt("stdDId"));
				hunhe.setStdBId(rs.getString("stdBId"));
				hunhe.setStdJob(rs.getString("stdJob"));
				hunhe.setStdStatus(rs.getInt("stdStatus"));
				hunhe.setStdPassword(rs.getString("stdPassword"));
				hunhe.setBuildFloor(rs.getInt("buildFloor"));
				hunhe.setBuildStyle(rs.getString("buildStyle"));
				hunhe.setBuildName(rs.getString("buildName"));
				hunhe.setDorDId(rs.getInt("dorDId"));
				hunhe.setDorPnum(rs.getInt("dorPnum"));
				hunhe.setDorAnum(rs.getInt("dorAnum"));
				hunhe.setDorGrade(rs.getInt("dorGrade"));
				hunhe.setDorName(rs.getString("dorName"));
				hunhe.setStayId(rs.getInt("stayId"));
				hunhe.setStayBed(rs.getString("stayBed"));
				hunhe.setStayAt(rs.getString("stayAt"));
				hunhe.setStaySt(rs.getString("staySt"));
				list.add(hunhe);
			}
			return list;
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
		}
		finally
		{
			
		}
	}
    public List<Hunhe2> gethunhe2(int username,int start) {                      //��ȡ���û���hunhe2��������ҳ
		PreparedStatement stmt=null;
		ResultSet rs =null;
		if(start != 0)start = start*4;
		String sql = "select * from student,repair where student.stdPId=repair.repPId and student.stdDId=? order by repStart limit "+start+","+4;
		try
		{
			List<Hunhe2> list= new ArrayList<Hunhe2>();
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, username);		
			rs  = stmt.executeQuery();
			while(rs.next()){
				Hunhe2 hunhe2 = new Hunhe2();
				hunhe2.setStdPId(rs.getString("stdPId"));
				hunhe2.setStdName(rs.getString("stdName"));
				hunhe2.setStdClass(rs.getString("stdClass"));
				hunhe2.setRepReason(rs.getString("repReason"));
				hunhe2.setRepStart(rs.getString("repStart"));
				hunhe2.setRepEnd(rs.getString("repEnd"));
				hunhe2.setRepStatus(rs.getInt("repStatus"));
				list.add(hunhe2);
			}
			return list;
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
		}
		finally
		{
			
		}
	}
    public List<Hunhe3> gethunhe3(String username,int start) {                      //��ȡ���û���hunhe3������¥ȫ����������ҳ
		PreparedStatement stmt=null;
		ResultSet rs =null;
		if(start != 0)start = start*4;
		String sql = "select * from student,bad,dormitory where student.stdPId=bad.badPId and dormitory.dorId = student.stdDId and bad.badBId=? order by badTime desc limit "+start+","+4;
		try
		{
			List<Hunhe3> list= new ArrayList<Hunhe3>();
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setString(1, username);		
			rs  = stmt.executeQuery();
			while(rs.next()){
				Hunhe3 hunhe3 = new Hunhe3();
				hunhe3.setStdPId(rs.getString("stdPId"));
				hunhe3.setStdName(rs.getString("stdName"));
				hunhe3.setStdClass(rs.getString("stdClass"));
				hunhe3.setStdBId(rs.getString("stdBId"));
				hunhe3.setBadScore(rs.getInt("badScore"));
				hunhe3.setBadRes(rs.getString("badRes"));
				hunhe3.setBadTime(rs.getString("badTime"));
				hunhe3.setDorDId(rs.getInt("dorDId"));
				list.add(hunhe3);
			}
			return list;
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
		}
		finally
		{
			
		}
	}
    public List<Hunhe3> gethunhe3_1(int username,int start) {                      //��ȡ���û���hunhe3����������ȫ����������ҳ
		PreparedStatement stmt=null;
		ResultSet rs =null;
		if(start != 0)start = start*4;
		String sql = "select * from student,bad,dormitory where student.stdPId=bad.badPId and dormitory.dorId = student.stdDId and student.stdDId=? order by badTime desc limit "+start+","+4;
		try
		{
			List<Hunhe3> list= new ArrayList<Hunhe3>();
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, username);		
			rs  = stmt.executeQuery();
			while(rs.next()){
				Hunhe3 hunhe3 = new Hunhe3();
				hunhe3.setStdPId(rs.getString("stdPId"));
				hunhe3.setStdName(rs.getString("stdName"));
				hunhe3.setStdClass(rs.getString("stdClass"));
				hunhe3.setStdBId(rs.getString("stdBId"));
				hunhe3.setBadScore(rs.getInt("badScore"));
				hunhe3.setBadRes(rs.getString("badRes"));
				hunhe3.setBadTime(rs.getString("badTime"));
				hunhe3.setDorDId(rs.getInt("dorDId"));
				list.add(hunhe3);
			}
			return list;
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
		}
		finally
		{
			
		}
	}
    public int get_allnumber(int username)            //���hunhe1���ܹ�����
    {
    	int t = 0;
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "select * from student,building,dormitory,stay where student.stdPId=stay.stayPId and dormitory.dorId=? and student.stdBId=building.buildBId and student.stdDId=dormitory.dorId";
		try
		{	
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, username);			
			rs  = stmt.executeQuery();
  			while(rs.next()){
  				t++;
  			}
  			return t;
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
			
		}
		finally
		{
			
		}
    }
    public int get_allnumber2(int username)            //���hunhe2���ܹ�����
    {
    	int t = 0;
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "select * from student,repair where student.stdPId=repair.repPId and student.stdDId=?";
		try
		{	
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, username);			
			rs  = stmt.executeQuery();
  			while(rs.next()){
  				t++;
  			}
  			return t;
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
			
		}
		finally
		{
			
		}
    }
    public int get_allnumber3_1(String username)            //���hunhe3���ܹ�����
    {
    	int t = 0;
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "select * from student,bad,dormitory where student.stdPId=bad.badPId and dormitory.dorId = student.stdDId and student.stdBId=? order by badTime desc";
		try
		{	
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setString(1, username);			
			rs  = stmt.executeQuery();
  			while(rs.next()){
  				t++;
  			}
  			return t;
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
			
		}
		finally
		{
			
		}
    }
    public int get_allnumber3_2(int username)            //���hunhe3�ĸ�����
    {
    	int t = 0;
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "select * from student,bad,dormitory where student.stdPId=bad.badPId and dormitory.dorId = student.stdDId and student.stdDId=? order by badTime desc";
		try
		{	
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, username);			
			rs  = stmt.executeQuery();
  			while(rs.next()){
  				t++;
  			}
  			return t;
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
			
		}
		finally
		{
			
		}
    }
    public void update_password(Student student)              //����һ��ѧ������Ϣ
    {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "update student set stdPassword=? where stdPId=?";
		 try
 		{
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setString(1, student.getStdPassword());
			stmt.setString(2, student.getStdPId());			
		int rows  = stmt.executeUpdate();
      }
		catch(Exception e)
		{
			throw new RuntimeException(e);	
		}
		finally
		{
			
		}
    }
    public void update_email(Student student)              //����һ��ѧ������Ϣ
    {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "update student set stdEmail=? where stdPId=?";
		 try
 		{
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setString(1, student.getStdEmail());
			stmt.setString(2, student.getStdPId());			
		int rows  = stmt.executeUpdate();
      }
		catch(Exception e)
		{
			throw new RuntimeException(e);	
		}
		finally
		{
			
		}
    }
    public void add(Repair repair)                   //����һ�б��ޱ�
    {
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "insert into repair(repPId,repBId,repDId,repReason,repStart,repEnd,repStatus) values(?,?,?,?,?,?,?)";
		try
 		{
		Connection con = JDBCUtils.getConnection();   
		stmt = con.prepareStatement(sql);
		stmt.setString(1, repair.getRepPId());
		stmt.setString(2, repair.getRepBId());
		stmt.setInt(3, repair.getRepDId());
		stmt.setString(4, repair.getRepReason());
		stmt.setString(5, repair.getRepStart());
		stmt.setString(6, repair.getRepEnd());
		stmt.setInt(7, repair.getRepStatus());
		int rows  = stmt.executeUpdate();
      }
		catch(Exception e)
		{
			throw new RuntimeException(e);	
		}
		finally
		{
			
		}
    }
    public void update_dorm(String name,int id)                   //�޸��������Ϣ
    {
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "update dormitory set dorName=? where dorId=?";
		try
 		{
		Connection con = JDBCUtils.getConnection();   
		stmt = con.prepareStatement(sql);
		stmt.setString(1, name);
		stmt.setInt(2, id);
		int rows  = stmt.executeUpdate();
      }
		catch(Exception e)
		{
			throw new RuntimeException(e);	
		}
		finally
		{
			
		}
    }
    public int bad_paihang(int dorid,String bid)            //��������ڱ���������
    {
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "select (count(*)+1) as jlp from dormitory where dorBId=? and dorGrade>(select max(dorGrade) from dormitory where dorId=?)";
		int m = 0;
		try
		{	
			Connection con = JDBCUtils.getConnection();   
			stmt = con.prepareStatement(sql);
			stmt.setString(1, bid);
			stmt.setInt(2, dorid);
			rs  = stmt.executeQuery();
			if(rs.next()){
				m = rs.getInt("jlp");
			}
			return m;
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
			
		}
		finally
		{
			
		}
    }
    public int job_find_in_dormitory(String job,int id)                  //���ұ��������Ƿ������᳤
    {
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "select * from student where student.stdDId=? and student.stdJob=?";
		int t = 0;
		try
 		{
		Connection con = JDBCUtils.getConnection();   
		stmt = con.prepareStatement(sql);
		stmt.setInt(1, id);	
		stmt.setString(2, job);			
		rs  = stmt.executeQuery();
	    while(rs.next()){
			t++;
		}
		return t;
 		}
		catch(Exception e)
		{
			throw new RuntimeException(e);	
		}
		finally
		{
			
		}
    }
    public int job_find_in_building(String job,int floor)                  //���ұ�¥���Ƿ����в㳤
    {
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "select * from student,building where student.stdBId=building.buildBId and student.stdJob=? and building.buildFloor=?";
		int t = 0;
		try
 		{
		Connection con = JDBCUtils.getConnection();   
		stmt = con.prepareStatement(sql);
		stmt.setString(1, job);	
		stmt.setInt(2, floor);	
		rs  = stmt.executeQuery();
	    while(rs.next()){
			t++;
		}
		return t;
 		}
		catch(Exception e)
		{
			throw new RuntimeException(e);	
		}
		finally
		{
			
		}
    }
    public void update_job(String job,String name)                   //�޸�ѧ����ְλ��Ϣ
    {
		PreparedStatement stmt=null;
		ResultSet rs =null;
		String sql = "update student set stdJob=? where stdPId=?";
		try
 		{
		Connection con = JDBCUtils.getConnection();   
		stmt = con.prepareStatement(sql);
		stmt.setString(1, job);
		stmt.setString(2, name);
		int rows  = stmt.executeUpdate();
        }
		catch(Exception e)
		{
			throw new RuntimeException(e);	
		}
		finally
		{
			
		}
    }
}
