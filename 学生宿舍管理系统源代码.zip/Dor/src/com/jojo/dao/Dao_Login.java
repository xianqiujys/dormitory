package com.jojo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.jojo.entity.Admin;
import com.jojo.entity.Student;
import com.jojo.utils.JDBCUtils;


public class Dao_Login {
    public boolean check_login_admin(String username,String password) throws Exception            //��ʵ����Ա�ܷ��½
    {
 		Connection con = JDBCUtils.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "select * from admin where adminName=? and adminPassword=?";
       	stmt = con.prepareStatement(sql);
   		stmt.setString(1, username);
   		stmt.setString(2, password);
   		rs = stmt.executeQuery();
           if(rs.next())
             {
              return true;
             }
           else {
           	return false;
           }
    }
    public boolean check_login_student(String username,String password) throws Exception            //��ʵѧ���ܷ��½
    {
 		Connection con = JDBCUtils.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "select * from student where stdPId=? and stdPassword=?";
       	stmt = con.prepareStatement(sql);
   		stmt.setString(1, username);
   		stmt.setString(2, password);
   		rs = stmt.executeQuery();
           if(rs.next())
             {
              return true;
             }
           else {
           	return false;
           }
    }
    public String get_name_student(String username) throws Exception            //��ȡѧ������
    {
 		Connection con = JDBCUtils.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "select * from student where stdPId=?";
       	stmt = con.prepareStatement(sql);
   		stmt.setString(1, username);
   		rs = stmt.executeQuery();
           if(rs.next())
             {
              return rs.getString("stdName");
             }
           else {
           	return null;
           }
    }
    public String get_email_admin(String username) throws Exception            //��ȡ����Ա����
    {
 		Connection con = JDBCUtils.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "select * from admin where adminName=?";
       	stmt = con.prepareStatement(sql);
   		stmt.setString(1, username);
   		rs = stmt.executeQuery();
           if(rs.next())
             {
              return rs.getString("adminEmail");
             }
           else {
           	return null;
           }
    }
    public String get_email_student(String username) throws Exception            //��ȡ�û�����
    {
 		Connection con = JDBCUtils.getConnection();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = "select * from student where stdPId=?";
       	stmt = con.prepareStatement(sql);
   		stmt.setString(1, username);
   		rs = stmt.executeQuery();
           if(rs.next())
             {
              return rs.getString("stdEmail");
             }
           else {
           	return null;
           }
    }
}
