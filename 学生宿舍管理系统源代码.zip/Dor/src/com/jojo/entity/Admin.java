package com.jojo.entity;

/**
 * ��6������Ա��
 */

public class Admin {

	private String adminName;
	// ����
	private String adminBId;
	// ¥����
	private String adminTel;
	// �绰
	private String adminPassword;
	// ����
	private int adminStatus;
	// ״̬
	private String adminEmail;
	// ����
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdminBId() {
		return adminBId;
	}
	public void setAdminBId(String adminBId) {
		this.adminBId = adminBId;
	}
	public String getAdminTel() {
		return adminTel;
	}
	public void setAdminTel(String adminTel) {
		this.adminTel = adminTel;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	public int getAdminStatus() {
		return adminStatus;
	}
	public void setAdminStatus(int adminStatus) {
		this.adminStatus = adminStatus;
	}
	public String getAdminEmail() {
		return adminEmail;
	}
	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}
	
}
