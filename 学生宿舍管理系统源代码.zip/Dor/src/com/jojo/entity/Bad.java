package com.jojo.entity;

/**
 * ��4��Υ�ͱ�
 */

public class Bad {
	
	private int badId;
	// Υ�ͼ�¼��ţ�������
	private int badDId;
	// ������
	private String badBId;
	// ¥����
	private String badPId;
	// ѧ��
	private int badScore;
	// �۳�����
	private String badRes;
	// Υ��ԭ��
	private String badTime;
	// Υ��ʱ��
	
	public int getBadId() {
		return badId;
	}
	public void setBadId(int badId) {
		this.badId = badId;
	}
	public int getBadDId() {
		return badDId;
	}
	public void setBadDId(int badDId) {
		this.badDId = badDId;
	}
	public String getBadBId() {
		return badBId;
	}
	public void setBadBId(String badBId) {
		this.badBId = badBId;
	}
	public String getBadPId() {
		return badPId;
	}
	public void setBadPId(String badPId) {
		this.badPId = badPId;
	}
	public int getBadScore() {
		return badScore;
	}
	public void setBadScore(int badScore) {
		this.badScore = badScore;
	}
	public String getBadRes() {
		return badRes;
	}
	public void setBadRes(String badRes) {
		this.badRes = badRes;
	}
	public String getBadTime() {
		return badTime;
	}
	public void setBadTime(String badTime) {
		this.badTime = badTime;
	}
	
}
