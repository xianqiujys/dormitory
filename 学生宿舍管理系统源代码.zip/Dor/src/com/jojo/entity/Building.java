package com.jojo.entity;

/**
 * ��5��¥��
 */

public class Building {
	
	private String buildBId;
	// ¥����
	private int buildFloor;
	// ¥����
	private String buildStyle;
	// ��ʽ
	private String buildName;
	// ����Ա����
	public String getBuildBId() {
		return buildBId;
	}
	
	public void setBuildBId(String buildBId) {
		this.buildBId = buildBId;
	}
	public int getBuildFloor() {
		return buildFloor;
	}
	public void setBuildFloor(int buildFloor) {
		this.buildFloor = buildFloor;
	}
	public String getBuildStyle() {
		return buildStyle;
	}
	public void setBuildStyle(String buildStyle) {
		this.buildStyle = buildStyle;
	}
	public String getBuildName() {
		return buildName;
	}
	public void setBuildName(String buildName) {
		this.buildName = buildName;
	}
	
}
