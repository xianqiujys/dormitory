package com.jojo.entity;

/**
 * ��2�������
 */

public class Dormitory {
	
	private int dorId;
	// �����ţ�������
	private int dorDId;
	// �����
	private String dorBId;
	// ¥����
	private int dorPnum;
	// ��ס����
	private int dorAnum;
	// ʵס����
	private int dorGrade;
	// �������
	private String dorName;
	// ��������
	
	public int getDorId() {
		return dorId;
	}
	public void setDorId(int dorId) {
		this.dorId = dorId;
	}
	public int getDorDId() {
		return dorDId;
	}
	public void setDorDId(int dorDId) {
		this.dorDId = dorDId;
	}
	public String getDorBId() {
		return dorBId;
	}
	public void setDorBId(String dorBId) {
		this.dorBId = dorBId;
	}
	public int getDorPnum() {
		return dorPnum;
	}
	public void setDorPnum(int dorPnum) {
		this.dorPnum = dorPnum;
	}
	public int getDorAnum() {
		return dorAnum;
	}
	public void setDorAnum(int dorAnum) {
		this.dorAnum = dorAnum;
	}
	public int getDorGrade() {
		return dorGrade;
	}
	public void setDorGrade(int dorGrade) {
		this.dorGrade = dorGrade;
	}
	public String getDorName() {
		return dorName;
	}
	public void setDorName(String dorName) {
		this.dorName = dorName;
	}
}
