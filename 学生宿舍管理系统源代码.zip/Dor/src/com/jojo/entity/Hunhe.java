package com.jojo.entity;

/**
 * student,dormitory,building,stay�ı����
 */

public class Hunhe {
	private String stdPId;
	// ѧ��
	private String stdName;
	// ����
	private String stdTel;
	// �绰
	private String stdSex;
	// �Ա�
	private String stdClass;
	// �༶
	private String stdEmail;
	// ����
	private int stdDId;
	// ������
	private String stdBId;
	// ¥����
	private String stdJob;
	// ְ��
	private int stdStatus;
	// ״̬
	private String stdPassword;
	// ����
	private int buildFloor;
	// ¥����
	private String buildStyle;
	// ��ʽ
	private String buildName;
	// ����Ա����
	private int dorDId;
	// �����
	private int dorPnum;
	// ��ס����
	private int dorAnum;
	// ʵס����
	private int dorGrade;
	// �������
	private String dorName;
	// ��������
	private int stayId;
	// ס�ޱ�ţ�������
	private String staySt;
	// ��סʱ��
	private String stayAt;
	// ����ʱ��
	private String stayBed;
	// ����
	
	public int getStayId() {
		return stayId;
	}
	public void setStayId(int stayId) {
		this.stayId = stayId;
	}
	public String getStaySt() {
		return staySt;
	}
	public void setStaySt(String staySt) {
		this.staySt = staySt;
	}
	public String getStayAt() {
		return stayAt;
	}
	public void setStayAt(String stayAt) {
		this.stayAt = stayAt;
	}
	public String getStayBed() {
		return stayBed;
	}
	public void setStayBed(String stayBed) {
		this.stayBed = stayBed;
	}
	public String getStdPId() {
		return stdPId;
	}
	public void setStdPId(String stdPId) {
		this.stdPId = stdPId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public String getStdTel() {
		return stdTel;
	}
	public void setStdTel(String stdTel) {
		this.stdTel = stdTel;
	}
	public String getStdSex() {
		return stdSex;
	}
	public void setStdSex(String stdSex) {
		this.stdSex = stdSex;
	}
	public String getStdClass() {
		return stdClass;
	}
	public void setStdClass(String stdClass) {
		this.stdClass = stdClass;
	}
	public String getStdEmail() {
		return stdEmail;
	}
	public void setStdEmail(String stdEmail) {
		this.stdEmail = stdEmail;
	}
	public int getStdDId() {
		return stdDId;
	}
	public void setStdDId(int stdDId) {
		this.stdDId = stdDId;
	}
	public String getStdBId() {
		return stdBId;
	}
	public void setStdBId(String stdBId) {
		this.stdBId = stdBId;
	}
	public String getStdJob() {
		return stdJob;
	}
	public void setStdJob(String stdJob) {
		this.stdJob = stdJob;
	}
	public int getStdStatus() {
		return stdStatus;
	}
	public void setStdStatus(int stdStatus) {
		this.stdStatus = stdStatus;
	}
	public String getStdPassword() {
		return stdPassword;
	}
	public void setStdPassword(String stdPassword) {
		this.stdPassword = stdPassword;
	}
	public int getBuildFloor() {
		return buildFloor;
	}
	public void setBuildFloor(int buildFloor) {
		this.buildFloor = buildFloor;
	}
	public String getBuildStyle() {
		return buildStyle;
	}
	public void setBuildStyle(String buildStyle) {
		this.buildStyle = buildStyle;
	}
	public String getBuildName() {
		return buildName;
	}
	public void setBuildName(String buildName) {
		this.buildName = buildName;
	}
	public int getDorDId() {
		return dorDId;
	}
	public void setDorDId(int dorDId) {
		this.dorDId = dorDId;
	}
	public int getDorPnum() {
		return dorPnum;
	}
	public void setDorPnum(int dorPnum) {
		this.dorPnum = dorPnum;
	}
	public int getDorAnum() {
		return dorAnum;
	}
	public void setDorAnum(int dorAnum) {
		this.dorAnum = dorAnum;
	}
	public int getDorGrade() {
		return dorGrade;
	}
	public void setDorGrade(int dorGrade) {
		this.dorGrade = dorGrade;
	}
	public String getDorName() {
		return dorName;
	}
	public void setDorName(String dorName) {
		this.dorName = dorName;
	}
	
	
}
