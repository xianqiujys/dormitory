package com.jojo.entity;

/**
 * student,repair�������
 */

public class Hunhe2 {
	private String stdPId;
	// ѧ��
	private String stdName;
	// ����
	private String stdClass;
	// �༶
	private String repReason;
	// ����ԭ��
	private String repStart;
	// ����ʱ��
	private String repEnd;
	// ����ʱ��
	private int repStatus;
	// ��������
	
	public String getStdPId() {
		return stdPId;
	}
	public void setStdPId(String stdPId) {
		this.stdPId = stdPId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public String getStdClass() {
		return stdClass;
	}
	public void setStdClass(String stdClass) {
		this.stdClass = stdClass;
	}
	public String getRepReason() {
		return repReason;
	}
	public void setRepReason(String repReason) {
		this.repReason = repReason;
	}
	public String getRepStart() {
		return repStart;
	}
	public void setRepStart(String repStart) {
		this.repStart = repStart;
	}
	public String getRepEnd() {
		return repEnd;
	}
	public void setRepEnd(String repEnd) {
		this.repEnd = repEnd;
	}
	public int getRepStatus() {
		return repStatus;
	}
	public void setRepStatus(int repStatus) {
		this.repStatus = repStatus;
	}
	
	
	
}
