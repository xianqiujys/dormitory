package com.jojo.entity;

/**
 * student,bad,dormitory�������
 */

public class Hunhe3 {
	private String stdPId;
	// ѧ��
	private String stdName;
	// ����
	private String stdClass;
	// �༶
	private String stdBId;
	// ¥����
	private int badScore;
	// �۳�����
	private String badRes;
	// Υ��ԭ��
	private String badTime;
	// Υ��ʱ��
	private int dorDId;
	// �����
	
	public String getStdPId() {
		return stdPId;
	}
	public void setStdPId(String stdPId) {
		this.stdPId = stdPId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public String getStdClass() {
		return stdClass;
	}
	public void setStdClass(String stdClass) {
		this.stdClass = stdClass;
	}
	public int getBadScore() {
		return badScore;
	}
	public void setBadScore(int badScore) {
		this.badScore = badScore;
	}
	public String getBadRes() {
		return badRes;
	}
	public void setBadRes(String badRes) {
		this.badRes = badRes;
	}
	public String getBadTime() {
		return badTime;
	}
	public void setBadTime(String badTime) {
		this.badTime = badTime;
	}
	public int getDorDId() {
		return dorDId;
	}
	public void setDorDId(int dorDId) {
		this.dorDId = dorDId;
	}
	public String getStdBId() {
		return stdBId;
	}
	public void setStdBId(String stdBId) {
		this.stdBId = stdBId;
	}
	
}
