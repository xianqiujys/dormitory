package com.jojo.entity;

/**
 * ��7�����ޱ�
 */

public class Repair {

	private int repId;
	// ���(����Id)
	private String repPId;
	// ѧ��
	private String repBId;
	// ¥����
	private int repDId;
	// ������
	private String repReason;
	// ����ԭ��
	private String repStart;
	// ����ʱ��
	private String repEnd;
	// ����ʱ��
	private int repStatus;
	// ��������
	
	public int getRepId() {
		return repId;
	}
	public void setRepId(int repId) {
		this.repId = repId;
	}
	public String getRepPId() {
		return repPId;
	}
	public void setRepPId(String repPId) {
		this.repPId = repPId;
	}
	public String getRepBId() {
		return repBId;
	}
	public void setRepBId(String repBId) {
		this.repBId = repBId;
	}
	public int getRepDId() {
		return repDId;
	}
	public void setRepDId(int repDId) {
		this.repDId = repDId;
	}
	public String getRepReason() {
		return repReason;
	}
	public void setRepReason(String repReason) {
		this.repReason = repReason;
	}
	public int getRepStatus() {
		return repStatus;
	}
	public void setRepStatus(int repStatus) {
		this.repStatus = repStatus;
	}
	public String getRepStart() {
		return repStart;
	}
	public void setRepStart(String repStart) {
		this.repStart = repStart;
	}
	public String getRepEnd() {
		return repEnd;
	}
	public void setRepEnd(String repEnd) {
		this.repEnd = repEnd;
	}
}
