package com.jojo.entity;

/**
 * ��3��ס�ޱ�
 */

public class Stay {

	private int stayId;
	// ס�ޱ�ţ�������
	private int stayDId;
	// ������
	private String stayBId;
	// ¥����
	private String stayPId;
	// ѧ��
	private String staySt;
	// ��סʱ��
	private String stayAt;
	// ����ʱ��
	private String stayBed;
	// ����
	
	public int getStayId() {
		return stayId;
	}
	public void setStayId(int stayId) {
		this.stayId = stayId;
	}
	public int getStayDId() {
		return stayDId;
	}
	public void setStayDId(int stayDId) {
		this.stayDId = stayDId;
	}
	public String getStayBId() {
		return stayBId;
	}
	public void setStayBId(String stayBId) {
		this.stayBId = stayBId;
	}
	public String getStayPId() {
		return stayPId;
	}
	public void setStayPId(String stayPId) {
		this.stayPId = stayPId;
	}
	public String getStaySt() {
		return staySt;
	}
	public void setStaySt(String staySt) {
		this.staySt = staySt;
	}
	public String getStayAt() {
		return stayAt;
	}
	public void setStayAt(String stayAt) {
		this.stayAt = stayAt;
	}
	public String getStayBed() {
		return stayBed;
	}
	public void setStayBed(String stayBed) {
		this.stayBed = stayBed;
	}
	
}
