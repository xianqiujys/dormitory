package com.jojo.entity;

/**
 * ��1��ѧ����
 */

public class Student {

		private String stdPId;
		// ѧ��
		private String stdName;
		// ����
		private String stdTel;
		// �绰
		private String stdSex;
		// �Ա�
		private String stdClass;
		// �༶
		private String stdEmail;
		// ����
		private int stdDId;
		// ������
		private String stdBId;
		// ¥����
		private String stdJob;
		// ְ��
		private int stdStatus;
		// ״̬
		private String stdPassword;
		// ����
		
		public String getStdPId() {
			return stdPId;
		}
		public void setStdPId(String stdPId) {
			this.stdPId = stdPId;
		}
		public String getStdName() {
			return stdName;
		}
		public void setStdName(String stdName) {
			this.stdName = stdName;
		}
		public String getStdTel() {
			return stdTel;
		}
		public void setStdTel(String stdTel) {
			this.stdTel = stdTel;
		}
		public String getStdSex() {
			return stdSex;
		}
		public void setStdSex(String stdSex) {
			this.stdSex = stdSex;
		}
		public String getStdClass() {
			return stdClass;
		}
		public void setStdClass(String stdClass) {
			this.stdClass = stdClass;
		}
		public String getStdEmail() {
			return stdEmail;
		}
		public void setStdEmail(String stdEmail) {
			this.stdEmail = stdEmail;
		}
		public int getStdDId() {
			return stdDId;
		}
		public void setStdDId(int stdDId) {
			this.stdDId = stdDId;
		}
		public String getStdBId() {
			return stdBId;
		}
		public void setStdBId(String stdBId) {
			this.stdBId = stdBId;
		}
		public String getStdJob() {
			return stdJob;
		}
		public void setStdJob(String stdJob) {
			this.stdJob = stdJob;
		}
		public int getStdStatus() {
			return stdStatus;
		}
		public void setStdStatus(int stdStatus) {
			this.stdStatus = stdStatus;
		}
		public String getStdPassword() {
			return stdPassword;
		}
		public void setStdPassword(String stdPassword) {
			this.stdPassword = stdPassword;
		}
		
}
