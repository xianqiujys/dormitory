package com.jojo.exception;

public class DBException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DBException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DBException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DBException(String message, Exception exception) {
		super(message, exception);
		// TODO Auto-generated constructor stub
	}

}
