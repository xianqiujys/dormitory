package com.jojo.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 **��¼������
 */
public class LoginFilter implements Filter {

	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		// ת��
		HttpServletRequest req = (HttpServletRequest) arg0;
		HttpServletResponse resp = (HttpServletResponse) arg1;
		HttpSession session = req.getSession();

		// ǰ̨����
		String[] urlFilter = new String[] { "login.html" };

		// ǰ̨������
		String[] notUrlFilter = new String[] { ".css", "js", "jpg", "png" };

		// ����û������URI
		String path = req.getRequestURI();

		// ѭ��
		/*for (String url : urlFilter) {
			if (!path.contains(url)) {
				arg2.doFilter(req, resp);
				return;
			} else {
				// ��sessionȡ���Ѿ���¼��֤��ƾ֤
				User user = (User) session.getAttribute("LOGIN_USER");
				// ��֤�Ƿ��¼
				if (user == null) {
					// ��ת����½ҳ��
					resp.sendRedirect("login.jsp");
					return;
				} else {
					// �Ѿ���½,�����˴�����
					arg2.doFilter(req, resp);
					return;
				}
			}
		}*/
		
		// ��֤�Ƿ��к�׺��
		/*for (String notUrl : notUrlFilter) {
			if (!path.contains(notUrl)) {
				arg2.doFilter(req, resp);
				return;
			} else {
				
			}
		}*/
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

}
