package com.jojo.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jojo.dao.Dao_Dormitory;
import com.jojo.entity.Building;
import com.jojo.entity.Dormitory;
import com.jojo.entity.Hunhe;
import com.jojo.entity.Student;



/**
 * Servlet implementation class controller_geren_stu
 */
public class controller_geren_stu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public controller_geren_stu() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ѧ��������Ϣ����ҳ��
		response.setContentType("text/html;charset = utf-8");
		request.setCharacterEncoding("utf-8");
		Dao_Dormitory dor = new Dao_Dormitory();
		HttpSession session = request.getSession();
		//String t = request.getParameter("page");
		int page = 0;
		//page = Integer.parseInt(t);
		String pid = (String) session.getAttribute("pid");
		Student stu = dor.getOneStudent(pid);
		Building bul = dor.getOneBuilding(pid);
		Dormitory dorm = dor.getOneDormitory(pid);
		List<Hunhe> hunhelist = dor.gethunhe(dorm.getDorId(), page);
		int all_number = 0;
		all_number = dor.get_allnumber(dorm.getDorId());
		session.setAttribute("page", page);
		session.setAttribute("all_number", all_number);
		session.setAttribute("stu", stu);
		session.setAttribute("bul", bul);
		session.setAttribute("dorm", dorm);
		session.setAttribute("hunhelist", hunhelist);
		session.setAttribute("dorid", dorm.getDorId());
		response.sendRedirect("geren_student.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
