package com.jojo.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jojo.dao.Dao_Dormitory;
import com.jojo.entity.Building;
import com.jojo.entity.Dormitory;
import com.jojo.entity.Hunhe2;
import com.jojo.entity.Hunhe3;
import com.jojo.entity.Student;

/**
 * Servlet implementation class controller_lookat_bad_stu
 */
public class controller_lookat_bad_stu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public controller_lookat_bad_stu() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ѧ��ͨ����Ϣ�鿴�Ŀ���ҳ��
		response.setContentType("text/html;charset = utf-8");
		request.setCharacterEncoding("utf-8");
		Dao_Dormitory dor = new Dao_Dormitory();
		HttpSession session = request.getSession();
		String pid = (String) session.getAttribute("pid");
		String t = request.getParameter("page");
		int page = Integer.parseInt(t);
		Student stu = dor.getOneStudent(pid);
		Building bul = dor.getOneBuilding(pid);
		Dormitory dorm = dor.getOneDormitory(pid);
		List<Hunhe3> hunhelist = dor.gethunhe3(stu.getStdBId(), page);
		int all_number = 0;
		int dor_number = 0;	
		int paihang = 0;
		all_number = dor.get_allnumber3_1(stu.getStdBId());
		dor_number = dor.get_allnumber3_2(stu.getStdDId());
		paihang = dor.bad_paihang(stu.getStdDId(), stu.getStdBId());
	    hunhelist = dor.gethunhe3(stu.getStdBId(), page);
		session.setAttribute("page", page);
		session.setAttribute("all_number", all_number);
		session.setAttribute("dor_number", dor_number);
		session.setAttribute("paihang", paihang);
		session.setAttribute("stu", stu);
		session.setAttribute("bul", bul);
		session.setAttribute("dorm", dorm);
		session.setAttribute("hunhelist", hunhelist);
		session.setAttribute("bid", stu.getStdBId());
		session.setAttribute("dorid", dorm.getDorDId());
		session.setAttribute("id", dorm.getDorId());
		session.setAttribute("select", "����ͨ��");
		response.sendRedirect("lookat_bad.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
