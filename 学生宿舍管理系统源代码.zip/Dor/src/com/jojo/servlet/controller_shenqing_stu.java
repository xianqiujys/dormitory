package com.jojo.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jojo.dao.Dao_Dormitory;
import com.jojo.entity.Building;
import com.jojo.entity.Dormitory;
import com.jojo.entity.Student;

/**
 * Servlet implementation class controller_shenqing_stu
 */
public class controller_shenqing_stu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public controller_shenqing_stu() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ѧ��ְλ�������ҳ��
		response.setContentType("text/html;charset = utf-8");
		request.setCharacterEncoding("utf-8");
		Dao_Dormitory dor = new Dao_Dormitory();
		HttpSession session = request.getSession();
		String pid = (String) session.getAttribute("pid");
		Student stu = dor.getOneStudent(pid);
		Building bul = dor.getOneBuilding(pid);
		Dormitory dorm = dor.getOneDormitory(pid);
		session.setAttribute("stu", stu);
		session.setAttribute("bul", bul);
		session.setAttribute("dorm", dorm);
		response.sendRedirect("shenqing_student.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
