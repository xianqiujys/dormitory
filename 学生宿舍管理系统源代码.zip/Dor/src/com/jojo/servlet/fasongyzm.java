package com.jojo.servlet;

import java.awt.HeadlessException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import com.jojo.dao.Dao_Login;
import com.jojo.entity.Admin;
import com.jojo.entity.Student;
import com.jojo.utils.MailUtil;

/**
 * Servlet implementation class fasongyzm
 */
public class fasongyzm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public fasongyzm() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ������֤�루��¼���棩
		Dao_Login d = new Dao_Login();
		response.setContentType("text/html;charset = utf-8");
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String type = request.getParameter("type");
		MailUtil m = new MailUtil();
		if(type.equals("����Ա"))
		{
			session.setAttribute("ID", username);
			session.setAttribute("Password", password);
			try {
				if(d.check_login_admin(username, password))
				{
				try {
					if(d.get_email_admin(username) != null)
					{
					String k = m.sendEmail(d.get_email_admin(username));
					session.setAttribute("yzm", k);
					JOptionPane.showMessageDialog(null, "���ͳɹ�����ע����գ�");
					response.sendRedirect("/Dor/login.jsp");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "���䲻��Ϊ�գ�");
						response.sendRedirect("/Dor/login.jsp");
					}
				} catch (HeadlessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
				else
				{
					JOptionPane.showMessageDialog(null, "�û������벻ƥ��");
					response.sendRedirect("/Dor/login.jsp");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else
		{
			session.setAttribute("ID", username);
			session.setAttribute("Password", password);
			try {
				if(d.check_login_student(username, password))
				{
				try {
					if(d.get_email_student(username) != null)
					{
					String k = m.sendEmail(d.get_email_student(username));
					session.setAttribute("yzm", k);
					JOptionPane.showMessageDialog(null, "���ͳɹ�����ע����գ�");
					response.sendRedirect("/Dor/login.jsp");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "���䲻��Ϊ�գ�");
						response.sendRedirect("/Dor/login.jsp");
					}
				} catch (HeadlessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
				else
				{
					JOptionPane.showMessageDialog(null, "�û������벻ƥ��");
					response.sendRedirect("/Dor/login.jsp");
				}
			}
			 catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
