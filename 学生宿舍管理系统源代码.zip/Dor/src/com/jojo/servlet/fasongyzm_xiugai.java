package com.jojo.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import com.jojo.dao.Dao_Login;
import com.jojo.utils.MailUtil;

/**
 * Servlet implementation class fasongyzm_xiugai
 */
public class fasongyzm_xiugai extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public fasongyzm_xiugai() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//������֤�루�޸Ľ��棩
		response.setContentType("text/html;charset = utf-8");
		request.setCharacterEncoding("utf-8");
		Dao_Login d = new Dao_Login();
		HttpSession session = request.getSession();
		String youxiang = request.getParameter("youxiang");
		String yanzhengma = request.getParameter("yanzhengma");
		String pid = (String) session.getAttribute("pid");
		String yuanyouxiang = null;
		try {
			yuanyouxiang = d.get_email_student(pid);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		session.setAttribute("youxiang", youxiang);
		MailUtil m = new MailUtil();
		String k = null;
		if(youxiang!="")
		{
		 if(!yuanyouxiang.equals(youxiang))
		 {
			try {
				k = m.sendEmail(youxiang);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			session.setAttribute("yzm", k);
			JOptionPane.showMessageDialog(null, "���ͳɹ�����ע����գ�");
			response.sendRedirect("/Dor/xiugai_student.jsp");
		 }
		 else
		 {
			JOptionPane.showMessageDialog(null, "������ͬ�������޸ģ�");
			response.sendRedirect("/Dor/xiugai_student.jsp");
		 }
		}
		else
		{
			JOptionPane.showMessageDialog(null, "���䲻��Ϊ�գ�");
			response.sendRedirect("/Dor/xiugai_student.jsp");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
