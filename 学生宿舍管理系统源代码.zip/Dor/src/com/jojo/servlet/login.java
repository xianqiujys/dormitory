package com.jojo.servlet;

import java.awt.HeadlessException;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import com.jojo.dao.Dao_Login;

/**
 * Servlet implementation class login
 */
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//��¼�ж�ҳ��
		response.setContentType("text/html;charset = utf-8");
		request.setCharacterEncoding("utf-8");
		Dao_Login d = new Dao_Login();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String type = request.getParameter("type");
		String validate = request.getParameter("validate");
		HttpSession session = request.getSession();
		session.setAttribute("ID", username);
		session.setAttribute("Password", password);
		if(username != ""&&password != ""&&validate!="")
		{
			if(type.equals("����Ա"))
			{
				try {
					if(d.check_login_admin(username, password)) //�ж��˺�������ȷ
					{
						 String k = (String) session.getAttribute("yzm");
						  if(!k.equals(validate))
						  {
							  JOptionPane.showMessageDialog(null, "��֤�벻�����");
							  response.sendRedirect("/Dor/login.jsp");
						  }
						  else
						  {
							  session.setAttribute("username", username);
							  JOptionPane.showMessageDialog(null, "��½�ɹ���"+username+"��ӭ������");
							  session.setAttribute("yzm", "1");
							  k = (String) session.getAttribute("yzm");
							  response.sendRedirect("/Dor/index_admin.jsp");
						  }
					}
					else
					{
						JOptionPane.showMessageDialog(null, "�û��������벻��ƥ�䣡");
						response.sendRedirect("/Dor/login.jsp");
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				try {
					if(d.check_login_student(username, password)) //�ж��˺�������ȷ
					{
						 String k = (String) session.getAttribute("yzm");
						  if(!k.equals(validate))
						  {
							  JOptionPane.showMessageDialog(null, "��֤�벻�����");
							  response.sendRedirect("/Dor/login.jsp");
						  }
						  else
						  {
							  session.setAttribute("pid", username);
							  session.setAttribute("username", d.get_name_student(username));
							  JOptionPane.showMessageDialog(null, "��½�ɹ���"+d.get_name_student(username)+"��ӭ������");
							  session.setAttribute("yzm", "1");
							  response.sendRedirect("/Dor/index.jsp");
						  }
					}
					else
					{
						JOptionPane.showMessageDialog(null, "�û��������벻��ƥ�䣡");
						response.sendRedirect("/Dor/login.jsp");
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				    //session.setAttribute("t",t);
					//session.setAttribute("username", d.get_name(username));
					//session.setAttribute("loginid", d.get_id(username));
					//JOptionPane.showMessageDialog(null, "��½�ɹ���"+d.get_name(username)+"��ӭ������");
		}
		else
		{
			JOptionPane.showMessageDialog(null, "�������Ϣ��������");
			response.sendRedirect("/Dor/login.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
