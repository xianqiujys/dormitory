package com.jojo.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jojo.dao.Dao_Dormitory;
import com.jojo.entity.Hunhe3;

/**
 * Servlet implementation class lookat_bad_stu_chaxun
 */
public class lookat_bad_stu_chaxun extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public lookat_bad_stu_chaxun() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//ѧ��ͨ����Ϣ�鿴�Ĳ�ѯҳ��
				response.setContentType("text/html;charset = utf-8");
				request.setCharacterEncoding("utf-8");
				Dao_Dormitory dor = new Dao_Dormitory();
				HttpSession session = request.getSession();
				String bad_select[] = request.getParameterValues("bad_select");
				int page = 0;
				int id = (int) session.getAttribute("id");
				String bid = (String) session.getAttribute("bid");
				List<Hunhe3> hunhelist = new ArrayList<Hunhe3>();
				if(bad_select[0].equals("����ͨ��"))
				{
				    hunhelist = dor.gethunhe3(bid, page);
				}
				else
				{
				    hunhelist = dor.gethunhe3_1(id, page);
				}
				session.setAttribute("select", bad_select[0]);
				session.setAttribute("page", page);
				session.setAttribute("hunhelist", hunhelist);
				response.sendRedirect("lookat_bad.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
