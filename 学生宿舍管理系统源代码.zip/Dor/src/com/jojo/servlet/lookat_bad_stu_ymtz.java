package com.jojo.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jojo.dao.Dao_Dormitory;
import com.jojo.entity.Hunhe2;
import com.jojo.entity.Hunhe3;

/**
 * Servlet implementation class lookat_bad_stu_ymtz
 */
public class lookat_bad_stu_ymtz extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public lookat_bad_stu_ymtz() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//ѧ��ͨ����Ϣ�鿴����תҳ��
		response.setContentType("text/html;charset = utf-8");
		request.setCharacterEncoding("utf-8");
		Dao_Dormitory dor = new Dao_Dormitory();
		HttpSession session = request.getSession();
		String select = (String) session.getAttribute("select");
		int all_number = (int) session.getAttribute("all_number");
		int dor_number = (int) session.getAttribute("dor_number");
		int id = (int) session.getAttribute("id");
		String bid = (String) session.getAttribute("bid");
		String t = request.getParameter("page");
		int page = Integer.parseInt(t);
		List<Hunhe3> hunhelist = new ArrayList<Hunhe3>();
		if(select.equals("����ͨ��"))
		{
			if(page*4 == all_number)
			{
			   page = all_number/4-1;
			}
		    else if(page*4 > all_number)
		    {
			page = all_number/4;
		    }
		    if(page < 0)page = 0;
		    hunhelist = dor.gethunhe3(bid, page);
		}
		else
		{
			if(page*4 == dor_number)
			{
			   page = dor_number/4-1;
			}
		    else if(page*4 > dor_number)
		    {
			page = dor_number/4;
		    }
		    if(page < 0)page = 0;
		    hunhelist = dor.gethunhe3_1(id, page);
		}
		session.setAttribute("page", page);
		session.setAttribute("hunhelist", hunhelist);
		response.sendRedirect("lookat_bad.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
