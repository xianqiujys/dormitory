package com.jojo.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jojo.dao.Dao_Dormitory;
import com.jojo.entity.Hunhe;
import com.jojo.entity.Hunhe2;

/**
 * Servlet implementation class lookat_repair_stu_ymtz
 */
public class lookat_repair_stu_ymtz extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public lookat_repair_stu_ymtz() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//ѧ��������Ϣ�鿴����תҳ��
		response.setContentType("text/html;charset = utf-8");
		request.setCharacterEncoding("utf-8");
		Dao_Dormitory dor = new Dao_Dormitory();
		HttpSession session = request.getSession();
		int all_number = (int) session.getAttribute("all_number");
		int dorid = (int) session.getAttribute("dorid");
		String t = request.getParameter("page");
		int page = Integer.parseInt(t);
		if(page*4 == all_number)
		{
		   page = all_number/4-1;
		}
	    else if(page*4 > all_number)
	    {
		page = all_number/4;
	    }
	    if(page < 0)page = 0;
		session.setAttribute("page", page);
		List<Hunhe2> hunhelist = dor.gethunhe2(dorid, page);
		session.setAttribute("hunhelist", hunhelist);
		response.sendRedirect("lookat_repair.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
