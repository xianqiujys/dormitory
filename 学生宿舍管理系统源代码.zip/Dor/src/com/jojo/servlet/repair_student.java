package com.jojo.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import com.jojo.dao.Dao_Dormitory;
import com.jojo.entity.Building;
import com.jojo.entity.Dormitory;
import com.jojo.entity.Repair;
import com.jojo.entity.Student;

/**
 * Servlet implementation class repair_student
 */
public class repair_student extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public repair_student() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ѧ������ȷ��
		response.setContentType("text/html;charset = utf-8");
		request.setCharacterEncoding("utf-8");
		String baoxiuriqi = request.getParameter("baoxiuriqi");
		String context = request.getParameter("context");
		if (context != "") {
			Dao_Dormitory dor = new Dao_Dormitory();
			HttpSession session = request.getSession();
			String pid = (String) session.getAttribute("pid");
			Student stu = dor.getOneStudent(pid);
			Repair repair = new Repair();
			repair.setRepPId(stu.getStdPId());
			repair.setRepBId(stu.getStdBId());
			repair.setRepDId(stu.getStdDId());
			repair.setRepReason(context);
			repair.setRepStart(baoxiuriqi);
			repair.setRepEnd(null);
			repair.setRepStatus(0);
			try {
				dor.add(repair);
			} catch (Exception e) {
				e.printStackTrace();
			}
			JOptionPane.showMessageDialog(null, "���ӳɹ���");
			response.sendRedirect("/Dor/repair_student.jsp");
		} else {
			JOptionPane.showMessageDialog(null, "�����뱨��ԭ��");
			response.sendRedirect("/Dor/repair_student.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
