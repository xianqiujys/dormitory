package com.jojo.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import com.jojo.dao.Dao_Dormitory;
import com.jojo.entity.Building;
import com.jojo.entity.Dormitory;
import com.jojo.entity.Student;

/**
 * Servlet implementation class shenqing_queren_student
 */
public class shenqing_queren_student extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public shenqing_queren_student() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ѧ������ְλȷ��
		response.setContentType("text/html;charset = utf-8");
		request.setCharacterEncoding("utf-8");
		String position_select[] = request.getParameterValues("position_select");
		HttpSession session = request.getSession();
		Student stu = (Student) session.getAttribute("stu");
		Building bul = (Building) session.getAttribute("bul");
		Dormitory dorm = (Dormitory) session.getAttribute("dorm");
		Dao_Dormitory dor = new Dao_Dormitory();
		int p = 0;
		if (position_select[0].equals("�᳤")) {		
			try {
				p = dor.job_find_in_dormitory("�᳤",stu.getStdDId());
			} catch (Exception e) {
				e.printStackTrace();
			}
			if(p == 0)
			{
				dor.update_job("�᳤", stu.getStdPId());
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
				response.sendRedirect("/Dor/shenqing_student.jsp");
			}
			else
			{
				JOptionPane.showMessageDialog(null, "���������Ѿ����᳤�ˣ�");
				response.sendRedirect("/Dor/shenqing_student.jsp");
			}	
		} 
		else {
			try {
				p = dor.job_find_in_building("�㳤",bul.getBuildFloor());
			} catch (Exception e) {
				e.printStackTrace();
			}
			if(p == 0)
			{
				if(dorm.getDorGrade() < 90)
				{
					JOptionPane.showMessageDialog(null, "��������ķ���û�ﵽҪ�󣬲�������Ϊ�㳤��");
					response.sendRedirect("/Dor/shenqing_student.jsp");
				}
				else
				{
					dor.update_job("�㳤", stu.getStdPId());
					JOptionPane.showMessageDialog(null, "���ӳɹ���");
					response.sendRedirect("/Dor/shenqing_student.jsp");
				}
			}
			else
			{
				JOptionPane.showMessageDialog(null, "��������Ѿ��в㳤�ˣ�");
				response.sendRedirect("/Dor/shenqing_student.jsp");
			}	
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
