package com.jojo.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import com.jojo.dao.Dao_Dormitory;
import com.jojo.entity.Dormitory;
import com.jojo.entity.Repair;
import com.jojo.entity.Student;

/**
 * Servlet implementation class tijiao_queren_stu
 */
public class tijiao_queren_stu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public tijiao_queren_stu() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ѧ���޸�������ȷ��
				response.setContentType("text/html;charset = utf-8");
				request.setCharacterEncoding("utf-8");
				String sushename = request.getParameter("sushename");
				if (sushename != "") {
					Dao_Dormitory dor = new Dao_Dormitory();
					HttpSession session = request.getSession();
					Dormitory dorm = (Dormitory) session.getAttribute("dorm");
					try {
						dor.update_dorm(sushename,dorm.getDorId());
					} catch (Exception e) {
						e.printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "���ӳɹ���");
					response.sendRedirect("controller_tijiao_stu");
				} else {
					JOptionPane.showMessageDialog(null, "��������Ϊ�գ�");
					response.sendRedirect("/Dor/tijiao_student.jsp");
				}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
