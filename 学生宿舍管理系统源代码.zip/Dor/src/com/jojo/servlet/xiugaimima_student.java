package com.jojo.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import com.jojo.dao.Dao_Dormitory;
import com.jojo.entity.Hunhe;
import com.jojo.entity.Student;

/**
 * Servlet implementation class xiugaimima_student
 */
public class xiugaimima_student extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public xiugaimima_student() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//�޸����루ѧ����
		response.setContentType("text/html;charset = utf-8");
		request.setCharacterEncoding("utf-8");
		String yuan = request.getParameter("yuanmima");
		String xin = request.getParameter("xinmima");
		String queren = request.getParameter("querenmima");
		Dao_Dormitory dor = new Dao_Dormitory();
		HttpSession session = request.getSession();
		String pid = (String) session.getAttribute("pid");
		Student stu = dor.getOneStudent(pid);
		System.out.println(stu.getStdPassword());
	    if(yuan != ""&&xin != ""&&queren != "")
	    {
	    	if(xin.equals(queren))
	    	{
	    		if(stu.getStdPassword().equals(yuan))
	    		{
	    			if(!yuan.equals(xin))
	    			{
	    			try {
	    				stu.setStdPassword(xin);
						dor.update_password(stu);
						JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
		    			response.sendRedirect("/Dor/controller_geren_stu?page=0");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	    			}
	    			else
	    			{
	    				JOptionPane.showMessageDialog(null, "Ҫ�޸ĵ�������ԭ������ͬ��");
		    			response.sendRedirect("/Dor/xiugai_student.jsp");
	    			}
	    		}
	    		else
	    		{
	    			JOptionPane.showMessageDialog(null, "ԭ���벻��ȷ��");
	    			response.sendRedirect("/Dor/xiugai_student.jsp");
	    		}
	    	}
	    	else
	    	{
	    		JOptionPane.showMessageDialog(null, "�������ȷ�����벻�����");
	    		response.sendRedirect("/Dor/xiugai_student.jsp");
	    	}
	    }
	    else
	    {
	    	JOptionPane.showMessageDialog(null, "�������Ϣ��������");
			response.sendRedirect("/Dor/xiugai_student.jsp");
	    }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
