package com.jojo.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import com.jojo.dao.Dao_Dormitory;
import com.jojo.entity.Student;

/**
 * Servlet implementation class xiugaiyouxiang_student
 */
public class xiugaiyouxiang_student extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public xiugaiyouxiang_student() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//�޸����䣨ѧ����
		response.setContentType("text/html;charset = utf-8");
		request.setCharacterEncoding("utf-8");
		String youxiang = request.getParameter("youxiang");
		String yanzhengma = request.getParameter("yanzhengma");
		Dao_Dormitory dor = new Dao_Dormitory();
		HttpSession session = request.getSession();
		String pid = (String) session.getAttribute("pid");
		Student stu = dor.getOneStudent(pid);
		String yzm = (String) session.getAttribute("yzm");
	    if(youxiang != ""&&yanzhengma != "")
	    {
	    	if(yanzhengma.equals(yzm))
	    	{
	    			try {
	    				stu.setStdEmail(youxiang);
						dor.update_email(stu);
						JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
						session.setAttribute("yzm", "0");
		    			response.sendRedirect("/Dor/controller_geren_stu?page=0");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	    	}
	    	else
	    	{
	    		JOptionPane.showMessageDialog(null, "��֤�벻�����");
	    		response.sendRedirect("/Dor/xiugai_student.jsp");
	    	}
	    }
	    else
	    {
	    	JOptionPane.showMessageDialog(null, "�������Ϣ��������");
			response.sendRedirect("/Dor/xiugai_student.jsp");
	    }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
