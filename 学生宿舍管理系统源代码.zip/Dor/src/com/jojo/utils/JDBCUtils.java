package com.jojo.utils;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class JDBCUtils {
 
    /*��ȡ���ݿ�����*/
    public static Connection getConnection() throws ClassNotFoundException, SQLException{
            Class.forName("com.mysql.jdbc.Driver");    
            String url = "jdbc:mysql://localhost:3307/dormitory?characterEncoding=utf-8";
            Connection conn = DriverManager.getConnection(url,"root","123456");
		    return conn;
    }
 
}
