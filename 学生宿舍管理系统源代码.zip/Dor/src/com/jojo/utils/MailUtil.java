package com.jojo.utils;

import java.util.Random;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;

public class MailUtil {
    public String sendEmail(String t) {
        SimpleEmail email = new SimpleEmail();
        email.setDebug(true);
        email.setHostName("smtp.126.com");
		String k = String.valueOf((int)((Math.random()*9+1)*100000));
		System.out.println(k);
        email.setAuthenticator(new DefaultAuthenticator("jiangyanshengy@126.com","a1745745"));
        try {
            email.setFrom("jiangyanshengy@126.com");
            email.addTo(t);
            email.setCharset("GB2312");
            email.setSubject("ɽ��������ѧ-ֻ�к�������");
            email.setMsg("��֤���ǣ�"+k+",�뱣�ܺ��Լ�����֤�룬�����˵�����");
            email.send();
            System.out.println("�ʼ����ͳɹ�");
        } catch (EmailException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return k;
    }

}